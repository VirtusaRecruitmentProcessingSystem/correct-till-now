package com.virtusa.model;

public class RateAndCommentModel {
	
	private int jobseeker_id;
	private int admin_rating;
	private char admin_comment;
	private int tr_rating;
	private char tr_comment;
	private int hr_rating;
	private char hr_comment;
	public int getJobseeker_id() {
		return jobseeker_id;
	}
	public void setJobseeker_id(int jobseeker_id) {
		this.jobseeker_id = jobseeker_id;
	}
	public int getAdmin_rating() {
		return admin_rating;
	}
	public void setAdmin_rating(int admin_rating) {
		this.admin_rating = admin_rating;
	}
	public char getAdmin_comment() {
		return admin_comment;
	}
	public void setAdmin_comment(char admin_comment) {
		this.admin_comment = admin_comment;
	}
	public int getTr_rating() {
		return tr_rating;
	}
	public void setTr_rating(int tr_rating) {
		this.tr_rating = tr_rating;
	}
	public char getTr_comment() {
		return tr_comment;
	}
	public void setTr_comment(char tr_comment) {
		this.tr_comment = tr_comment;
	}
	public int getHr_rating() {
		return hr_rating;
	}
	public void setHr_rating(int hr_rating) {
		this.hr_rating = hr_rating;
	}
	public char getHr_comment() {
		return hr_comment;
	}
	public void setHr_comment(char hr_comment) {
		this.hr_comment = hr_comment;
	}
	

}
