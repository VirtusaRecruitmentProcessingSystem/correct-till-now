package com.virtusa.entities;

public class AdminEntity {
	
	public AdminEntity() {
		
	}
	private String username;
	public String getusername() {
		return username;
	}
	public void setusername(String username) {
		
	}
	


}
