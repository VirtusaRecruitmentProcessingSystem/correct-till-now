package com.virtusa.services;


public interface AdminServices {


	public void addJobPost();
	public void deleteJobPost();
	//public void shortlistCandidates(String s);
	public void rate_comment();
}
