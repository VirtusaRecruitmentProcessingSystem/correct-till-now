package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Dao.ApplicantHomeDao;

/**
 * Servlet implementation class ViewHealthServlet
 */
@WebServlet("/ViewHealthServlet")
public class ViewHealthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ViewHealthServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		ServletContext sct = getServletContext();
		RequestDispatcher rd1 = sct.getRequestDispatcher("/ApplicantHome.jsp");
		rd1.include(request, response);

		ApplicantHomeDao ad = new ApplicantHomeDao();
		out.println("<center><table border=1 width=50% height=50%></center>");
		out.println("<br/><tr><th>vacancy Id</th><th>Role</th><th>Department</th><th>Apply</th><tr/>");

		ResultSet rs = ad.viewMarketing();
		try {
			while (rs.next()) {
				int vacid = rs.getInt("Vac_id");
				String role = rs.getString("role");
				String department = rs.getString("dept");
				out.print("<tr><td>" + vacid + "</td><td>" + role + "</td><td>" + department + "</td>"
						+ "<td><a href=Applicant.jsp>Apply</a></td></tr>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
