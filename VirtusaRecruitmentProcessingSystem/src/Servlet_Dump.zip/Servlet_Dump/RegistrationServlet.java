package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Registration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Dao.RegistrationDao;
import com.virtusa.entities.RegistrationEntity;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		

		PrintWriter out= response.getWriter();
		RegistrationEntity reg= new RegistrationEntity();
		reg.setUsertype(request.getParameter("usertype"));
		reg.setUsername(request.getParameter("username"));
		String password=request.getParameter("password");
		String cpsd=request.getParameter("confirmPassword");
		if(password.equals(cpsd))
		{
			reg.setPassword(password);
		}
		String usertype=reg.getUsertype();
		RegistrationDao reg1= new RegistrationDao();
		out.println(reg1.registration(reg));
	}

}
