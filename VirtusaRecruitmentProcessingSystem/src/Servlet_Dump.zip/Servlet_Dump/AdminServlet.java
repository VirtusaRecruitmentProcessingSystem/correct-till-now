package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Dao.AdminDAO;
import com.virtusa.entities.VacancyEntity;
import com.virusa.DaoConnection.DaoConnection;



/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String button = request.getParameter("button");
		PrintWriter out= response.getWriter();
		Connection con = DaoConnection.getConnection();
        if ("home".equals(button)) {
            out.println("home page");
        } else if ("view".equals(button)) {
        	
        	String sql="select * from applicant";
        	out.println("<table border=1 width=50% height=50%>");  
            out.println("<tr><th>app_id</th><th>app_name</th><th>email</th><th>phone</th><th>gender</th><th>dob</th><th>resume</th><tr>"); 
        	try {
				Statement st= con.createStatement();
				ResultSet rs=st.executeQuery(sql);
				while(rs.next())
				{
				String app_id= rs.getString(1);
				String app_name= rs.getString(2);
				String email= rs.getString(3);
				long phone= rs.getLong(4);
				String gender= rs.getString(5);
				String dob= rs.getString(6);
				
	
				out.write("<tr><td>"+app_id+"</td><td>"+app_name+"</td><td>"+email+"</td>" +
						"<td>"+phone+"</td><td>"+gender+"</td><td>"+dob+"</td></tr>");
				st.close();
				}
				
			}
        	catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        else if("add".equals(button))
        {
        	response.setContentType("text/html");
    		ServletContext sct= getServletContext();
    		RequestDispatcher rd1= sct.getRequestDispatcher("/addvacancy.jsp");
    		rd1.include(request, response);
    		
    		VacancyEntity ve= new VacancyEntity();
    		
    		ve.setVac_id(Integer.parseInt(request.getParameter("Vacid")));
			ve.setRole(request.getParameter("role"));
			ve.setNoOf_posts(Integer.parseInt(request.getParameter("noofposts")));
			ve.setDept(request.getParameter("dept"));
			
			AdminDAO ad= new AdminDAO();
			out.println(ad.advacancy(ve));
			
        }
		 
		
	}

}
