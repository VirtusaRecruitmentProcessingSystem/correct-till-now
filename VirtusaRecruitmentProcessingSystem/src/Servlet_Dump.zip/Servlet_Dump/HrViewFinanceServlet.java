package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Dao.HrViewFinanceDao;
import com.virusa.DaoConnection.DaoConnection;

/**
 * Servlet implementation class HrViewFinance
 */
@WebServlet("/HrViewFinanceServlet")
public class HrViewFinanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HrViewFinanceServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		ServletContext sct = getServletContext();
		RequestDispatcher rd1 = sct.getRequestDispatcher("/FinanceHR.jsp");
		rd1.include(request, response);

		HrViewFinanceDao hr = new HrViewFinanceDao();
		ResultSet rs = hr.viewFinance();
		out.println("<center><table border=1 width=50% height=50%></center>");
		out.println(
				"</br><tr><th>app_id</th><th>app_name</th><th>email</th><th>phone</th><th>gender</th><th>dob</th><th>resume</th><th>Vac_id</th><th>Shortlist</th><th>Reject</th><tr>");
		try {
			while (rs.next()) {
				String app_id = rs.getString("app_id");
				String app_name = rs.getString("app_name");
				String email = rs.getString("email");
				long phone = rs.getLong("phone");
				String gender = rs.getString("gender");
				String dob = rs.getString("dob");
				int Vac_id = rs.getInt("Vac_id");

				out.print("<tr><td>" + app_id + "</td><td>" + app_name + "</td><td>" + email + "</td>" + "<td>" + phone
						+ "</td><td>" + gender + "</td><td>" + dob + "</td><td>" + " " + "</td><td>" + Vac_id
						+ "</td><td><a href=Shortlist?app_id="+app_id+">Shortlist</a>"
						+ " </td><td><a href=Reject>Reject</a></td></tr>");

			}
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
