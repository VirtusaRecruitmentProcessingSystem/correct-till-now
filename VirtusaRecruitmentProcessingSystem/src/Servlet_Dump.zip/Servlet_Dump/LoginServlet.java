package com.virtusa.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.Dao.LoginDao;
import com.virtusa.entities.Login;

/**
 * Servlet implementation class LoginDao
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
   public LoginServlet() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Login login= new Login();
		doGet(request, response);
		PrintWriter out= response.getWriter();
		login.setUsertype(request.getParameter("usertype"));
		login.setUsername(request.getParameter("username"));
		login.setPassword(request.getParameter("password"));
		
		String usertype=login.getUsertype();
		String username=login.getUsername();
		String password=login.getPassword();
		LoginDao loginDao= new LoginDao();
		
		int cnt=loginDao.login(usertype, username, password);
		if(cnt==1)
		{
		
		if(usertype.equals(new String("Admin")))
		{
			out.println("login successful...welcome "+username);	
			RequestDispatcher disp=request.getRequestDispatcher("admin.jsp");
			disp.include(request, response);
		}
		
		if(usertype.equals(new String("Finhr")))
		{
			out.println("login successful...welcome "+username);	
			RequestDispatcher disp=request.getRequestDispatcher("FinanceHR.jsp"
					+ "");
			disp.include(request, response);
		}
		if(usertype.equals(new String("Marketinghr")))
		{
			out.println("login successful...welcome "+username);	
			RequestDispatcher disp=request.getRequestDispatcher("MarketingHR.jsp");
			disp.include(request, response);
		}
		if(usertype.equals(new String("HealthHr")))
		{
			out.println("login successful...welcome "+username);	
			RequestDispatcher disp=request.getRequestDispatcher("HealthHR.jsp");
			disp.include(request, response);
		}
		if(usertype.equals(new String("Manager")))
		{
			out.println("login successful...welcome "+username);	
			RequestDispatcher disp=request.getRequestDispatcher("Manager.jsp");
			disp.include(request, response);
		}
		if(usertype.equals(new String("Employ")))
		{
			out.println("login successful...welcome "+username);	
			RequestDispatcher disp=request.getRequestDispatcher("Employ.jsp");
			disp.include(request, response);
		}
		}
	}

}
